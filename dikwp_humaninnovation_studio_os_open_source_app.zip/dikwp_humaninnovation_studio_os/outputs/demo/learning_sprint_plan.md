# Learning Sprint Plan

## Week 1: AI literacy and tool boundary

Focus: Understand what AI can/cannot do; build verification habit.

Outputs: AI use policy, hallucination checklist

Cadence: standard sprint: 4 sessions/week, 45 minutes/session

## Week 2: Problem discovery and DIKWP framing

Focus: Convert vague interests into C=(D,I,K,W,P,R).

Outputs: problem ledger, purpose contract

Cadence: standard sprint: 4 sessions/week, 45 minutes/session

## Week 3: Evidence and domain grounding

Focus: Build source ledger, domain vocabulary and weak-signal map.

Outputs: evidence map, knowledge gap list

Cadence: standard sprint: 4 sessions/week, 45 minutes/session

## Week 4: Prototype and critique loop

Focus: Use AI as co-builder while retaining human judgment.

Outputs: prototype v0, critique notes

Cadence: standard sprint: 4 sessions/week, 45 minutes/session

## Week 5: Originality and narrative

Focus: Develop taste, storytelling, positioning and ethical boundary.

Outputs: portfolio story, demo script

Cadence: standard sprint: 4 sessions/week, 45 minutes/session

## Week 6: Public artifact and feedback

Focus: Publish a verifiable artifact and collect feedback.

Outputs: portfolio artifact, feedback ledger

Cadence: standard sprint: 4 sessions/week, 45 minutes/session

