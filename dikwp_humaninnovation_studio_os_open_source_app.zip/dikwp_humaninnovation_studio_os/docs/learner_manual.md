# Learner Manual

Use this system as an innovation gym.

1. Describe your role, goals and constraints.
2. List your current skills honestly.
3. Choose one project with social value and ambiguity.
4. Run the analyzer.
5. Follow the six-week sprint plan.
6. Build one artifact.
7. Keep an evidence ledger and AI-use disclosure.
8. Ask for mentor review.
