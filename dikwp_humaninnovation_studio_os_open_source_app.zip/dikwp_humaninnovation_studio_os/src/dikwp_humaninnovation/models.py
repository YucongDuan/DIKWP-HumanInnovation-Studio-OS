from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class Skill:
    name: str
    level: float
    relevance: float = 0.5
    ai_substitutability: float = 0.5
    human_anchor: float = 0.5

@dataclass
class Project:
    id: str
    title: str
    domain: str
    novelty: float
    ambiguity: float
    social_value: float
    technical_build: float
    evidence_need: float
    narrative_need: float
    ethical_risk: float = 0.2

@dataclass
class LearnerProfile:
    learner_id: str
    role: str
    domain: str
    goals: List[str]
    constraints: List[str]
    weekly_hours: float
    ai_access: str
    skills: List[Skill] = field(default_factory=list)
    projects: List[Project] = field(default_factory=list)

@dataclass
class AnalysisResult:
    learner_id: str
    route: str
    human_advantage_index: float
    innovation_capability_score: float
    automation_obsolescence_risk: float
    semantic_closure_score: float
    learning_path: List[Dict[str, Any]]
    action_tickets: List[Dict[str, Any]]
    dikwp_ledger: Dict[str, Any]
