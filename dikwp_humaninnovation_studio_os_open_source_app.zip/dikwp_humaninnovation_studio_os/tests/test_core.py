from dikwp_humaninnovation.analyzer import load_case, analyze, guard, analyze_file
from dikwp_humaninnovation.static_audit import audit
from pathlib import Path


def test_demo_analysis(tmp_path):
    profile=load_case('examples/sample_innovation_learning_case.json')
    res=analyze(profile)
    assert 0 <= res.human_advantage_index <= 1
    assert res.route in ['guided_portfolio_learning','urgent_reskilling_and_mentor_review','innovation_portfolio_acceleration']
    assert len(res.action_tickets) >= 3


def test_guard_blocks_bad_use():
    res=guard('Use AI to cheat and hide AI use')
    assert res['decision'] == 'block_and_redirect'


def test_file_outputs(tmp_path):
    report=analyze_file('examples/sample_innovation_learning_case.json', tmp_path)
    assert (tmp_path/'humaninnovation_report.json').exists()
    assert report['system'] == 'DIKWP HumanInnovation Studio OS'


def test_static_audit():
    res=audit('src')
    assert res['pass'] is True
