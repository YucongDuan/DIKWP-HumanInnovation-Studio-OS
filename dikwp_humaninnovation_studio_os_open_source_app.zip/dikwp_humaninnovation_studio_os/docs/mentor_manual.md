# Mentor Manual

Mentors should avoid using the platform as a ranking tool. Use it to open developmental conversations.

Recommended review questions:

- What problem did the learner choose and why?
- What evidence supports the problem framing?
- Which part was done by AI and which part by the learner?
- What did the learner reject or correct from AI output?
- What artifact proves new capability?
- What is the next six-week sprint?
