# Innovation Project Playbook

Each learner should build one artifact every six weeks:

- A working demo.
- A research brief.
- A field interview report.
- A dataset + evidence ledger.
- A product prototype.
- A teaching module.
- A policy or organization improvement proposal.

Each artifact must include: purpose, evidence, method, AI-use disclosure, originality statement, residual and next iteration.
