from pathlib import Path
import json
BANNED = ["requests", "urllib", "subprocess", "eval(", "exec(", "selenium", "playwright", "socket", "ftplib", "paramiko", "keyring", "getpass"]

def audit(root):
    root=Path(root)
    findings=[]
    for path in root.rglob('*.py'):
        if path.name == 'static_audit.py':
            continue
        text=path.read_text(encoding='utf-8', errors='ignore')
        for term in BANNED:
            if term in text:
                findings.append({"file":str(path), "term":term})
    return {"pass": len(findings)==0, "finding_count": len(findings), "findings": findings, "policy":"No network imports, subprocess, dynamic execution, credential capture, hidden telemetry, punitive ranking, or host mutation helpers in offline core."}

def write_audit(root, outpath):
    res=audit(root)
    Path(outpath).parent.mkdir(parents=True, exist_ok=True)
    Path(outpath).write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding='utf-8')
    return res
