# Portfolio Artifact Rubric

| Dimension | Weight | Evidence |
|---|---:|---|
| Problem framing | 20 | clear stakeholder and constraint map |
| Domain grounding | 20 | source ledger and expert concepts |
| Prototype / artifact | 20 | working demo, design, paper, dataset or field note |
| Human-AI collaboration | 15 | clear attribution and verification |
| Social usefulness | 15 | user value and risk boundary |
| Reflection and iteration | 10 | feedback loop and revision log |
