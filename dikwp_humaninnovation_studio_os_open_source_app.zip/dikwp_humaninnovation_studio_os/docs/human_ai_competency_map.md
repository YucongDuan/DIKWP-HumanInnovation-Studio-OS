# Human-AI Competency Map

The system defines ten core capabilities:

1. AI literacy and model limits.
2. Problem framing.
3. Domain evidence research.
4. Semantic closure under incomplete inputs.
5. Prototype building.
6. Human-AI collaboration workflow.
7. Ethical and legal boundary judgment.
8. Storytelling and persuasion.
9. Social usefulness and user empathy.
10. Portfolio evidence and feedback loop.
