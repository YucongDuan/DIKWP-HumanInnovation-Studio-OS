# Assessment Rubrics

Do not score people for exclusion. Score artifacts for learning and feedback.

Primary dimensions:

- Problem framing.
- Evidence discipline.
- Domain grounding.
- Prototype quality.
- Originality.
- Human-AI collaboration integrity.
- Social usefulness.
- Reflection and iteration.
