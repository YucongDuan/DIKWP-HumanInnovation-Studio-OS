# AI Use Policy

Allowed:
- brainstorming;
- explaining concepts;
- generating alternative structures;
- checking clarity;
- summarizing sources with verification;
- drafting code for learning.

Blocked:
- cheating;
- impersonation;
- fake credentials;
- plagiarism;
- hiding AI use where disclosure is required;
- manipulating others;
- harmful or high-stakes decisions without human review.
