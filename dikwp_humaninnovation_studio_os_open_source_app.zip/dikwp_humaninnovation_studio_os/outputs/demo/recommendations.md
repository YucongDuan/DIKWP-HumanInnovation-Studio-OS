# Recommendations

1. Build one verifiable portfolio artifact every six weeks.
2. Pair AI tool practice with domain evidence and human feedback.
3. Keep a source ledger and originality statement.
4. Prefer projects that combine ambiguity, social value and buildable prototypes.
5. Treat automation risk as a learning-priority signal, not as personal failure.
