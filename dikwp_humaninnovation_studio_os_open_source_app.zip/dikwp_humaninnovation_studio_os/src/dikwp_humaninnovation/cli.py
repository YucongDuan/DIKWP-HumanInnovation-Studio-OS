import argparse, json
from .analyzer import analyze_file, guard
from .static_audit import write_audit

def main(argv=None):
    parser=argparse.ArgumentParser(prog='humaninnovation')
    sub=parser.add_subparsers(dest='cmd', required=True)
    p=sub.add_parser('analyze')
    p.add_argument('case')
    p.add_argument('--out', default='outputs/demo')
    g=sub.add_parser('guard')
    g.add_argument('text')
    s=sub.add_parser('static-audit')
    s.add_argument('root')
    s.add_argument('--out', default='outputs/demo/static_boundary_audit_report.json')
    args=parser.parse_args(argv)
    if args.cmd=='analyze':
        print(json.dumps(analyze_file(args.case,args.out), ensure_ascii=False, indent=2))
    elif args.cmd=='guard':
        print(json.dumps(guard(args.text), ensure_ascii=False, indent=2))
    elif args.cmd=='static-audit':
        print(json.dumps(write_audit(args.root,args.out), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
