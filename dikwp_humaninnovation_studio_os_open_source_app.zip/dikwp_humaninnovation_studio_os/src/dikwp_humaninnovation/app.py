try:
    import streamlit as st
except Exception:
    st = None
from .analyzer import load_case, analyze

if st:
    st.set_page_config(page_title='DIKWP HumanInnovation Studio OS', layout='wide')
    st.title('DIKWP HumanInnovation Studio OS')
    st.write('AI-era human innovation capability learning platform.')
    uploaded=st.file_uploader('Upload case JSON', type=['json'])
    if uploaded:
        import json, tempfile
        data=uploaded.read().decode('utf-8')
        with tempfile.NamedTemporaryFile('w+', suffix='.json', delete=False) as f:
            f.write(data); f.flush()
            profile=load_case(f.name)
        res=analyze(profile)
        st.metric('Human Advantage Index', res.human_advantage_index)
        st.metric('Innovation Capability', res.innovation_capability_score)
        st.metric('Automation Risk', res.automation_obsolescence_risk)
        st.json(res.dikwp_ledger)
else:
    print('Install streamlit to run the app.')
