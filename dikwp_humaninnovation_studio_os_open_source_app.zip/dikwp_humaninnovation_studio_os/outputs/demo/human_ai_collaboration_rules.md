# Human-AI Collaboration Rules

- Use AI to expand options, not to replace judgment.
- Require evidence ledger for factual claims.
- Preserve originality statement for every portfolio artifact.
- Do not use AI for cheating, impersonation or credential inflation.
- High-stakes work requires human mentor or domain expert review.
