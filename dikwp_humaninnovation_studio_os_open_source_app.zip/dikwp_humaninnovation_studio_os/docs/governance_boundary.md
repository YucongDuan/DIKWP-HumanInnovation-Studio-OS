# Governance Boundary

This system must not be used to automatically hire, fire, rank, exclude, punish or diagnose people. It is for learning, portfolio building and mentor-supported innovation development.
