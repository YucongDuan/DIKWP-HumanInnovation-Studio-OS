import json, math, statistics
from pathlib import Path
from .models import Skill, Project, LearnerProfile, AnalysisResult

HUMAN_ANCHOR_KEYWORDS = ["empathy","judgment","taste","leadership","negotiation","care","field","hands-on","domain","storytelling","trust","ethics","design","research","problem framing"]
BLOCK_TERMS = ["cheat", "impersonate", "steal", "plagiarize", "fake credential", "hide ai", "bypass", "credential", "exam answer", "harass", "manipulate"]


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def load_case(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    skills=[Skill(**s) for s in data.get('skills', [])]
    projects=[Project(**p) for p in data.get('projects', [])]
    return LearnerProfile(
        learner_id=data.get('learner_id','learner-demo'),
        role=data.get('role','general learner'),
        domain=data.get('domain','general'),
        goals=data.get('goals',[]),
        constraints=data.get('constraints',[]),
        weekly_hours=float(data.get('weekly_hours',5)),
        ai_access=data.get('ai_access','basic'),
        skills=skills,
        projects=projects
    )


def score_skill(skill: Skill):
    gap = clamp(skill.relevance * (1 - skill.level))
    human_edge = clamp((skill.human_anchor + (1 - skill.ai_substitutability)) / 2)
    priority = clamp(0.55 * gap + 0.45 * human_edge)
    return {
        "skill": skill.name,
        "current_level": round(skill.level,3),
        "gap": round(gap,3),
        "human_edge": round(human_edge,3),
        "learning_priority": round(priority,3)
    }


def score_project(p: Project):
    innovation = clamp(0.25*p.novelty + 0.20*p.ambiguity + 0.20*p.social_value + 0.15*p.technical_build + 0.10*p.evidence_need + 0.10*p.narrative_need - 0.10*p.ethical_risk)
    ai_aug = clamp(0.20*p.technical_build + 0.20*p.evidence_need + 0.20*p.narrative_need + 0.15*p.ambiguity + 0.15*p.novelty + 0.10*p.social_value)
    human_anchor = clamp(0.25*p.ambiguity + 0.25*p.social_value + 0.15*p.narrative_need + 0.15*(1-p.ethical_risk) + 0.10*p.novelty + 0.10*p.evidence_need)
    route = "portfolio_project"
    if p.ethical_risk > 0.65:
        route = "mentor_review_required"
    if innovation > 0.75 and p.ethical_risk < 0.5:
        route = "flagship_project_candidate"
    return {
        "project_id": p.id,
        "title": p.title,
        "domain": p.domain,
        "innovation_score": round(innovation,3),
        "ai_augmentation_potential": round(ai_aug,3),
        "human_anchor_score": round(human_anchor,3),
        "route": route
    }


def build_learning_path(profile: LearnerProfile, skill_scores, project_scores):
    sorted_skills=sorted(skill_scores, key=lambda x: x['learning_priority'], reverse=True)
    top=[s['skill'] for s in sorted_skills[:4]]
    hours=profile.weekly_hours
    if hours < 3:
        cadence="micro-sprint: 3 sessions/week, 25 minutes/session"
    elif hours < 8:
        cadence="standard sprint: 4 sessions/week, 45 minutes/session"
    else:
        cadence="deep sprint: 5 sessions/week, 60-90 minutes/session"
    modules=[
        {"week":1,"module":"AI literacy and tool boundary","focus":"Understand what AI can/cannot do; build verification habit.","outputs":["AI use policy","hallucination checklist"]},
        {"week":2,"module":"Problem discovery and DIKWP framing","focus":"Convert vague interests into C=(D,I,K,W,P,R).","outputs":["problem ledger","purpose contract"]},
        {"week":3,"module":"Evidence and domain grounding","focus":"Build source ledger, domain vocabulary and weak-signal map.","outputs":["evidence map","knowledge gap list"]},
        {"week":4,"module":"Prototype and critique loop","focus":"Use AI as co-builder while retaining human judgment.","outputs":["prototype v0","critique notes"]},
        {"week":5,"module":"Originality and narrative","focus":"Develop taste, storytelling, positioning and ethical boundary.","outputs":["portfolio story","demo script"]},
        {"week":6,"module":"Public artifact and feedback","focus":"Publish a verifiable artifact and collect feedback.","outputs":["portfolio artifact","feedback ledger"]},
    ]
    for m in modules:
        m['cadence']=cadence
        m['priority_skills']=top
    return modules


def build_dikwp_ledger(profile, skill_scores, project_scores, route):
    return {
        "D": {
            "learner_id": profile.learner_id,
            "role": profile.role,
            "domain": profile.domain,
            "goals": profile.goals,
            "constraints": profile.constraints,
            "weekly_hours": profile.weekly_hours,
            "ai_access": profile.ai_access
        },
        "I": {
            "skill_count": len(profile.skills),
            "project_count": len(profile.projects),
            "top_skill_gaps": sorted(skill_scores, key=lambda x: x['learning_priority'], reverse=True)[:5],
            "project_routes": {p['project_id']: p['route'] for p in project_scores}
        },
        "K": {
            "mechanism": "AI-era competitiveness depends on human-AI augmentation, domain grounding, problem framing, evidence discipline, creativity and trustworthy execution.",
            "learning_model": "6-week portfolio sprint with evidence ledger and mentor review"
        },
        "W": {
            "boundaries": ["no cheating", "no impersonation", "no harmful manipulation", "no punitive ranking", "no fake credentials"],
            "values": ["human agency", "learning dignity", "evidence", "originality", "social usefulness"]
        },
        "P": {
            "goal": "help learner stay competitive by building transferable innovation capability",
            "value": "increase real capability rather than only tool dependency",
            "constraints": profile.constraints,
            "time": "6-week sprint plus quarterly portfolio review",
            "feedback": "artifact review, mentor review, peer feedback, self-reflection"
        },
        "R": {
            "route": route,
            "reliability": "Supported / prototype runproof",
            "residual": ["actual labor-market fit requires local validation", "self-reported skills may be biased", "portfolio quality requires human review"],
            "kill_conditions": ["uses AI to cheat", "claims guaranteed employment", "punitive use by employer", "no domain evidence", "no mentor review for high-stakes claims"]
        }
    }


def action_tickets(profile, skill_scores, project_scores):
    tickets=[]
    for i,s in enumerate(sorted(skill_scores, key=lambda x:x['learning_priority'], reverse=True)[:5], start=1):
        tickets.append({
            "ticket_id": f"skill-{i}",
            "type":"skill_sprint",
            "priority": round(s['learning_priority'],3),
            "owner":"learner",
            "action": f"Run a weekly deliberate-practice loop for {s['skill']}",
            "evidence_refs":["skill_self_assessment"],
            "rollback_plan":"Reduce scope and switch to micro-sprint if workload is unsustainable.",
            "kill_conditions":["no artifact produced", "AI output accepted without verification"]
        })
    for p in project_scores:
        tickets.append({
            "ticket_id": f"project-{p['project_id']}",
            "type":"portfolio_project",
            "priority": p['innovation_score'],
            "owner":"learner_with_mentor" if p['route']=="mentor_review_required" else "learner",
            "action": f"Develop project: {p['title']} ({p['route']})",
            "evidence_refs":["project_brief", "prototype", "source_ledger"],
            "rollback_plan":"Convert to case study if build scope is too large.",
            "kill_conditions":["unsafe or unethical use", "no evidence ledger", "no originality statement"]
        })
    return tickets


def analyze(profile: LearnerProfile):
    skill_scores=[score_skill(s) for s in profile.skills]
    project_scores=[score_project(p) for p in profile.projects]
    if skill_scores:
        human_adv=sum(s['human_edge'] for s in skill_scores)/len(skill_scores)
        risk=sum((1-s['human_edge'])*s['gap'] for s in skill_scores)/len(skill_scores)
    else:
        human_adv=0.5; risk=0.5
    if project_scores:
        innov=sum(p['innovation_score'] for p in project_scores)/len(project_scores)
    else:
        innov=0.4
    closure=clamp(0.30*human_adv + 0.30*innov + 0.20*(1-risk) + 0.20*min(1, profile.weekly_hours/8))
    route="guided_portfolio_learning"
    if risk > 0.65:
        route="urgent_reskilling_and_mentor_review"
    if innov > 0.68 and human_adv > 0.6:
        route="innovation_portfolio_acceleration"
    return AnalysisResult(
        learner_id=profile.learner_id,
        route=route,
        human_advantage_index=round(human_adv,3),
        innovation_capability_score=round(innov,3),
        automation_obsolescence_risk=round(risk,3),
        semantic_closure_score=round(closure,3),
        learning_path=build_learning_path(profile, skill_scores, project_scores),
        action_tickets=action_tickets(profile, skill_scores, project_scores),
        dikwp_ledger=build_dikwp_ledger(profile, skill_scores, project_scores, route)
    )


def analyze_file(path, outdir):
    profile=load_case(path)
    result=analyze(profile)
    out=Path(outdir); out.mkdir(parents=True, exist_ok=True)
    report={
        "system":"DIKWP HumanInnovation Studio OS",
        "version":"0.1.0",
        "learner_id":result.learner_id,
        "route":result.route,
        "human_advantage_index":result.human_advantage_index,
        "innovation_capability_score":result.innovation_capability_score,
        "automation_obsolescence_risk":result.automation_obsolescence_risk,
        "semantic_closure_score":result.semantic_closure_score,
        "action_boundary":"Learning, portfolio building and mentor support only; no punitive ranking or employment guarantee."
    }
    (out/'humaninnovation_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'dikwp_innovation_ledger.json').write_text(json.dumps(result.dikwp_ledger, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'learning_path_plan.json').write_text(json.dumps(result.learning_path, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'action_tickets.json').write_text(json.dumps(result.action_tickets, ensure_ascii=False, indent=2), encoding='utf-8')
    # CSV skill map and project portfolio
    skill_scores=[score_skill(s) for s in profile.skills]
    project_scores=[score_project(p) for p in profile.projects]
    csv='skill,current_level,gap,human_edge,learning_priority\n'+'\n'.join(f"{s['skill']},{s['current_level']},{s['gap']},{s['human_edge']},{s['learning_priority']}" for s in skill_scores)
    (out/'learner_skill_map.csv').write_text(csv+'\n', encoding='utf-8')
    pcsv='project_id,title,domain,innovation_score,ai_augmentation_potential,human_anchor_score,route\n'+'\n'.join(f"{p['project_id']},{p['title']},{p['domain']},{p['innovation_score']},{p['ai_augmentation_potential']},{p['human_anchor_score']},{p['route']}" for p in project_scores)
    (out/'innovation_project_portfolio.csv').write_text(pcsv+'\n', encoding='utf-8')
    # markdown packs
    path_md="# Learning Sprint Plan\n\n"
    for m in result.learning_path:
        path_md += f"## Week {m['week']}: {m['module']}\n\nFocus: {m['focus']}\n\nOutputs: {', '.join(m['outputs'])}\n\nCadence: {m['cadence']}\n\n"
    (out/'learning_sprint_plan.md').write_text(path_md, encoding='utf-8')
    rules="# Human-AI Collaboration Rules\n\n- Use AI to expand options, not to replace judgment.\n- Require evidence ledger for factual claims.\n- Preserve originality statement for every portfolio artifact.\n- Do not use AI for cheating, impersonation or credential inflation.\n- High-stakes work requires human mentor or domain expert review.\n"
    (out/'human_ai_collaboration_rules.md').write_text(rules, encoding='utf-8')
    rubric="# Portfolio Artifact Rubric\n\n| Dimension | Weight | Evidence |\n|---|---:|---|\n| Problem framing | 20 | clear stakeholder and constraint map |\n| Domain grounding | 20 | source ledger and expert concepts |\n| Prototype / artifact | 20 | working demo, design, paper, dataset or field note |\n| Human-AI collaboration | 15 | clear attribution and verification |\n| Social usefulness | 15 | user value and risk boundary |\n| Reflection and iteration | 10 | feedback loop and revision log |\n"
    (out/'portfolio_artifact_rubric.md').write_text(rubric, encoding='utf-8')
    rec="# Recommendations\n\n1. Build one verifiable portfolio artifact every six weeks.\n2. Pair AI tool practice with domain evidence and human feedback.\n3. Keep a source ledger and originality statement.\n4. Prefer projects that combine ambiguity, social value and buildable prototypes.\n5. Treat automation risk as a learning-priority signal, not as personal failure.\n"
    (out/'recommendations.md').write_text(rec, encoding='utf-8')
    return report


def guard(text: str):
    lower=text.lower()
    found=[t for t in BLOCK_TERMS if t in lower]
    if found:
        return {"decision":"block_and_redirect", "risk_terms":found, "safe_redirect":"Use the platform for learning, portfolio building, ethical AI collaboration and mentor-reviewed innovation."}
    review_terms=["job guarantee","promotion guarantee","replace worker","ranking employees","psychological diagnosis","medical decision"]
    found2=[t for t in review_terms if t in lower]
    if found2:
        return {"decision":"human_review_required", "risk_terms":found2, "safe_redirect":"Keep the use non-punitive and developmental."}
    return {"decision":"allow_learning_use", "risk_terms":[], "safe_redirect":"Proceed with evidence ledger and reflection."}
