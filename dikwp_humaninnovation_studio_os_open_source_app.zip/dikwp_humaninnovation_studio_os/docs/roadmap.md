# Roadmap

v0.1 offline studio and CLI.
v0.2 role-specific scenarios and mentor dashboard.
v0.3 portfolio registry and TrustPassport integration.
v0.4 organization cohort mode.
v0.5 bilingual curriculum packs.
